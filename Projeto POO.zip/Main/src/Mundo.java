import java.util.ArrayList;

public class Mundo {
    
    /**
     * @brief Classe Mundo
     * @since 12-10-2018
     * @author Victor de Moraes Milani / RA 221170533
     */
    /*    
    *Chamando o classe veiculo e atribuindo a variavel VEI como controle.
    */
    Veiculo vei = new Veiculo();
        
    //Criação dos ArrayLists dos veiculos.
       
    ArrayList <Carro> q7 = new ArrayList<>();
    ArrayList <Caminhao> truck = new ArrayList<>();
    ArrayList <Moto> f8 = new ArrayList<>();
    ArrayList <Bike> bmx = new ArrayList<>();

    /*    
    *MATRIZ PRINCIPAL ONDE TODO O JOGO ACONTECE = MATRIZ 30Linhas X 60Colunas.
    */    
    public int MP[][] = {{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1},
                        {1,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1},
                        {1,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1},
                        {1,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1},
                        {1,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1},
                        {1,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1},
                        {1,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
                            
    //Função que determinar as cores dos veiculos, bordas, fabricas e seus contadores
    
    public void CreatingWorld() {
	/*
        *Contadores para exibir quantidade de veículos 
        */
	int quantidade_de_carros = 0;
	int quantidade_de_motos = 0;
	int quantidade_de_caminhoes = 0;
        int quantidade_de_bikes = 0;
        /*
        * Contadores dos Veiculos.
        */
        quantidade_de_carros = q7.stream().map((_item) -> 1).reduce(quantidade_de_carros, Integer::sum);
        quantidade_de_caminhoes = truck.stream().map((_item) -> 1).reduce(quantidade_de_caminhoes, Integer::sum);
        quantidade_de_motos = f8.stream().map((_item) -> 1).reduce(quantidade_de_motos, Integer::sum);
        quantidade_de_bikes = bmx.stream().map((_item) -> 1).reduce(quantidade_de_bikes, Integer::sum);
		
	
    	for(int i = 0; i < 30; i++) {
            for(int j = 0; j < 60; j++) {
					
       
                switch (MP[i][j]) {
                    case 1:
                        System.out.print("\u001b[47m \033[0m"); //Bordas Brancas
                        break;
                    case 0:
                        System.out.print(" "); //Fundo Preto
                        break;
                    case 2:
                        System.out.print("\u001b[44m \033[0m"); //Fabricas Azuis
                        break;
                    case 3:
                        System.out.print("\u001b[42m \033[0m"); //Carros Verdes
                        break;
                    case 4:
                        System.out.print("\u001b[41m \033[0m"); // Caminhoes Vermelhos
                        break;
                    case 5:
                        System.out.print("\u001b[45;1m \033[0m"); // Motos Rosas
                        break;
                    case 6:
                        System.out.print("\u001b[46;1m \033[0m"); // Bike Azul Claro
                        break;
                    default:
                        break;
                }
        }
				
        System.out.println(""); //pula linha
    }	
	/*		
	*Colocando a legenda dos veiculos da matriz e suas cores
        */
        System.out.print("--------------------------------------------------------------");
        System.out.print("\n");
        System.out.println("\t\tLegenda : ");
        
        System.out.print("\n\t\tFabricas -> ");//Cor Azul
        System.out.print("\u001b[44m \033[0m");
        System.out.print("\u001b[44m \033[0m");
        System.out.print("\u001b[44m \033[0m");
        System.out.print("\u001b[44m \033[0m");
        System.out.print("\u001b[44m \033[0m");
        System.out.print("\u001b[44m \033[0m");
        System.out.print("\u001b[44m \033[0m");
        System.out.print("\u001b[44m \033[0m");
        System.out.println("");//pula linha
        System.out.print("\n\t\tBike -> ");//Cor azul claro
        System.out.print("\u001b[46;1m \033[0m");
        System.out.print("\u001b[46;1m \033[0m");
        System.out.print("\u001b[46;1m \033[0m");
        System.out.print("\u001b[46;1m \033[0m");
        System.out.print("\u001b[46;1m \033[0m");
        System.out.print("\u001b[46;1m \033[0m");
        System.out.print("\u001b[46;1m \033[0m");
        System.out.print("\u001b[46;1m \033[0m");
        System.out.println("");//pula linha
        System.out.print("\n\t\tCarros -> ");//Verde
	System.out.print("\u001b[42;1m \033[0m");
        System.out.print("\u001b[42;1m \033[0m");
        System.out.print("\u001b[42;1m \033[0m");
        System.out.print("\u001b[42;1m \033[0m");
        System.out.print("\u001b[42;1m \033[0m");
        System.out.print("\u001b[42;1m \033[0m");
        System.out.print("\u001b[42;1m \033[0m");
        System.out.print("\u001b[42;1m \033[0m");
        System.out.println("");//pula linha
        System.out.print("\n\t\tMotos -> ");//Cor Rosa
	System.out.print("\u001b[45;1m \033[0m");
        System.out.print("\u001b[45;1m \033[0m");
        System.out.print("\u001b[45;1m \033[0m");
        System.out.print("\u001b[45;1m \033[0m");
	System.out.print("\u001b[45;1m \033[0m");
        System.out.print("\u001b[45;1m \033[0m");
        System.out.print("\u001b[45;1m \033[0m");
        System.out.print("\u001b[45;1m \033[0m");
        System.out.println("");
        System.out.print("\n\t\tCaminhões -> ");//Cor vermelha
	System.out.print("\u001b[41m \033[0m");
        System.out.print("\u001b[41m \033[0m");
        System.out.print("\u001b[41m \033[0m");
        System.out.print("\u001b[41m \033[0m");
        System.out.print("\u001b[41m \033[0m");
        System.out.print("\u001b[41m \033[0m");
        System.out.print("\u001b[41m \033[0m");
        System.out.print("\u001b[41m \033[0m");
        System.out.println("\n");
        System.out.println("\n");
      
        System.out.println("\t\tCONTADORES : \n");
	//Print dos contadores.
	System.out.println("\t\tNúmero de Carros: " + quantidade_de_carros);
	System.out.println("\t\tNúmero de Motos: " + quantidade_de_motos);
        System.out.println("\t\tNúmero de Caminhões: " + quantidade_de_caminhoes);
        System.out.println("\t\tNúmero de Bikes: " + quantidade_de_bikes);
        System.out.print("--------------------------------------------------------------");
        System.out.print("\n");
    }
        
    /*
    *Função utilizada para zerar o mapa
    *O objetivo dessa função é fazer com que os veiculos nao destruam as fabricas e bordas.
    */
    
    public void RedoMap() {
    	for(int i = 0; i < 30; i++) {
            for(int j = 0; j < 60; j++) {
            	if(MP[i][j] != 1){
                    if(MP[i][j] != 2){
                        MP[i][j] = 0;
                    }
                }
            }   
        }    
        
        /*
        *Gerando Veiculos novos após a atualização do Mundo
        */
        
        for (int a = 0; a < q7.size(); a++) {
        int xa = q7.get(a).getX(); //Armazenar as coordenadas do carro no eixo X na variavel XA
        int ya = q7.get(a).getY(); //Armazenar as coordenadas do carro no eixo Y na variavel YA

            for(int i = 0; i<30; i++) {
		for(int j = 0; j < 60; j++) {
                    if(i == xa && j == ya) {//Se i for igual as coordenadas do carro armazenas no xa roda o programa e assim acontece igual com o j.
			if(MP[i][j] == 2) {
                                MP[i][j] = 2; 				
			}
			else {
                            MP[i][j] = 3; // 3 representa carro			
			}
                    }
                }
            }
        }
        
        for (int b = 0; b < bmx.size(); b++) {
            int xb = bmx.get(b).getX(); //Armazenar as coordenadas da Bike no eixo X na variavel XA
            int yb = bmx.get(b).getY(); //Armazenar as coordenadas da Bike no eixo Y na variavel XA

            for(int i = 0; i < 30; i++) { // linhas
		for(int j = 0; j < 60; j++) { // colunas
                    if(i == xb && j == yb) { //Se i for igual as coordenadas da bike armazenas no xb roda o programa e assim acontece igual com o j.
			if(MP[i][j] == 2) {
                                MP[i][j] = 2; 				
			}
			else {
                            MP[i][j] = 6; // 6 representa bike			
			}
                    }
                }
            }
        }
        
        for(int c  = 0; c < truck.size(); c++) {
            int bc = truck.get(c).getX();//Armazenar as coordenadas do Caminhão no eixo X na variavel XA
            int cc = truck.get(c).getY();//Armazenar as coordenadas do Caminhão no eixo Y na variavel YA
			
		for(int i = 0; i<30; i++) {// linhas
                    for(int j = 0; j < 60; j++) {// colunas
                        if(i == bc && j == cc) {//Se i for igual as coordenadas do caminhao armazenas no bc roda o programa e assim acontece igual com o j.
                                if(MP[i][j] == 2) {
					MP[i][j] = 2;		
				}
				else {
                                    MP[i][j] = 4; // 4 representa caminhao
							
				}
                            }
			}
                    }
		}
		
		for(int d = 0; d < f8.size(); d++) {
                    int ed = f8.get(d).getX();//Armazenar as coordenadas da Moto no eixo X na variavel XA
                    int fd = f8.get(d).getY();//Armazenar as coordenadas do Moto no eixo Y na variavel YA
			
			for(int i = 0; i<30; i++) {// linhas
                            for(int j = 0; j < 60; j++) {// colunas
				if(i == ed && j == fd) {//Se i for igual as coordenadas da moto armazenas no ed roda o programa e assim acontece igual com o j.
                                    if(MP[i][j] == 2) {
					MP[i][j] = 2;			
				}
				else {
                                    MP[i][j] = 5;// 5 representa moto
				}
                            }
                        }
                    }	
                }
		
	}
	
    /*Função collision serve para verificar as colisões que aconteceram entre os veiculos na matriz.
    | Regras : Caminhao > carro && moto | carro > Moto | carro = carro && moto = moto && caminhao = caminhao == -1 de cada um que se colidir igual |
    */
    
    public void collision(){
        
        /*
        *Colisão somente entre Q7 (carros) / Quando acontece isso 1 unico carro é retirado da matriz.
        */
        
        for (int i = 0; i < q7.size(); i ++) {
            for (int j = 0; j < q7.size(); j++) {
		if(q7.get(j).getX() == q7.get(i).getX() && q7.get(j).getY() == q7.get(i).getY()){//Essa condição diz que se o carro no getX (eixo X, tanto no I e no J) e estiver no getY(eixo Y, tanto no I e no J) se elas se colidirem igual 1 carro é removido.
                    if (i == j) { /// Essa parte verifica se o veículo é ele mesmo, e não o remove.
                        //Continua rodando normal.
                    }else {
                        q7.remove(q7.get(i));//Função remove
                    }	
                }
            }
	}
	
        /*
	*Colisão somente entre Trucks (caminhões) / Quando acontece isso 1 unico caminhão é retirado da matriz.
        */

	for (int i = 0; i < truck.size(); i ++) {
            for (int j = 0; j < truck.size(); j++) {
		if(truck.get(j).getX() == truck.get(i).getX() && truck.get(j).getY() == truck.get(i).getY()) {//Essa condição diz que se o caminhao no getX (eixo X, tanto no I e no J) e estiver no getY(eixo Y, tanto no I e no J) se elas se colidirem igual 1 caminhao é removido.
                    if(i == j) {				
                        //Continua rodando normal.
                    }else {
                        truck.remove(truck.get(i));//Função remove
                    }	
		}
            }
        }
	
        /*
	*Colisão somente entre F8 apenas (motos) / Quando acontece isso 1 unica moto é retirada da matriz.
        */

        for (int i = 0; i < f8.size(); i ++) {
            for (int j = 0; j < f8.size(); j++) {
                if(f8.get(j).getX() == f8.get(i).getX() && f8.get(j).getY() == f8.get(i).getY()) { //Essa condição diz que se a Moto no getX (eixo X, tanto no I e no J) e estiver no getY(eixo Y, tanto no I e no J) se elas se colidirem igual 1 moto é removida.
                    if(i == j) {
                       //Continua rodando normal.
                    }else {
                        f8.remove(f8.get(i));
                    }	
                }
            }
        }
        
        /*
        *Colisao somente entre Bmx apenas (Bikes) / Quando acontece isso 1 unica bike é retirada da matriz.
        */
        
        for (int i = 0; i < bmx.size(); i ++) {
            for (int j = 0; j < bmx.size(); j++) {
                if(bmx.get(j).getX() == bmx.get(i).getX() && bmx.get(i).getY() == bmx.get(j).getY()) { //Essa condição diz que se a Moto no getX (eixo X, tanto no I e no J) e estiver no getY(eixo Y, tanto no I e no J) se elas se colidirem igual 1 moto é removida.
                    if(i == j) {
                       //Continua rodando normal.
                    }else {
                        bmx.remove(bmx.get(i));
                    }	
                }
            }
        }
        
        /*
        *Colisoes entre Q7 e bmx (Carro e Bike) sobrevive Carro.
        */
        
	for(int i = 0; i < q7.size(); i++) {
            for (int j = 0; j < bmx.size(); j++) {
		if(bmx.get(j).getX() == q7.get(i).getX() && bmx.get(j).getY() == q7.get(i).getY()) {//Essa condição diz que se a carro e a moto no getX (eixo X, tanto no I e no J) e tambem estiver no getY(eixo Y, tanto no I e no J) se colidindo 1 moto é removida.
                    if(q7.size() > bmx.size()) {
                        
                    }else {
                        bmx.remove(bmx.get(i));//Função remove
                    }
                }			
            }
        }
        
        /*
        *Colisoes entre F8 e Bike (Moto e Bike) sobrevive Moto.
        */
        
	for(int i = 0; i < f8.size(); i++) {
            for (int j = 0; j < bmx.size(); j++) {
		if(bmx.get(j).getX() == f8.get(i).getX() && bmx.get(j).getY() == f8.get(i).getY()) {//Essa condição diz que se a carro e a moto no getX (eixo X, tanto no I e no J) e tambem estiver no getY(eixo Y, tanto no I e no J) se colidindo 1 moto é removida.
                    if(f8.size() > bmx.size()) {
                        
                       //Continua rodando normal.
                    }else {
                        bmx.remove(bmx.get(i));//Função remove
                    }
                }			
            }
        }
        
        /*
        * Colisoes entre Truck e bmx (Caminhão e Bike) sobrevive Caminhão.
        */
        
	for(int i = 0; i < truck.size(); i++) {
            for (int j = 0; j < bmx.size(); j++) {
		if(bmx.get(j).getX() == truck.get(i).getX() && bmx.get(j).getY() == truck.get(i).getY()) {//Essa condição diz que se a carro e a moto no getX (eixo X, tanto no I e no J) e tambem estiver no getY(eixo Y, tanto no I e no J) se colidindo 1 moto é removida.
                    if(truck.size() > bmx.size()) {
                        
                    }else {
                        bmx.remove(bmx.get(i));//Função remove
                    }
                }			
            }
        }
        
        /*
        * Colisoes entre Q7 e F8 (Carro e moto) sobrevive Carro.
        */
        
	for(int i = 0; i < q7.size(); i++) {
            for (int j = 0; j < f8.size(); j++) {
		if(f8.get(j).getX() == q7.get(i).getX() && f8.get(j).getY() == q7.get(i).getY()) {//Essa condição diz que se a carro e a moto no getX (eixo X, tanto no I e no J) e tambem estiver no getY(eixo Y, tanto no I e no J) se colidindo 1 moto é removida.
                    if(q7.size() > f8.size()) {
                       //Continua rodando normal.
                    }else {
                        f8.remove(f8.get(i)); //
                    }
                }			
            }
        }
	
        /*
	* Colisoes entre Truck e Q7 (caminhão e carro) sobrevive caminhao.
        */
        
	for(int i = 0; i < truck.size(); i++) {
            for (int j = 0; j < q7.size(); j++) {
		if(q7.get(j).getX() == truck.get(i).getX() && q7.get(j).getY() == truck.get(i).getY()) { //Essa condição diz que se o caminhao e o carro estiverem no getX (eixo X, tanto no I e no J) e tambem estiverem no getY(eixo Y, tanto no I e no J) se colidindo 1 carro é removido.
                    if(truck.size() > q7.size()) {
                        
                        //Continua rodando normal.
                    }else {
                        q7.remove(q7.get(i));//Função remove
                    }
		}
            }
	}
	
        /*
	*Colisoes entre Truck e F8 (caminhão e moto) sobrevive caminhão.
        */
        
        for(int i = 0; i < truck.size(); i++) {
            for (int j = 0; j < f8.size(); j++) {
		if(f8.get(j).getX() == truck.get(i).getX() && f8.get(j).getY() == truck.get(i).getY()) {//Essa condição diz que se o caminhao e a moto estiverem na mesma posição getX (eixo X, tanto no I e no J) e tambem estiverem no getY(eixo Y, tanto no I e no J) se colidindo 1 moto é removida.
                    if(truck.size() > f8.size()) {
                        
                        //Continua rodando normal.
                    }else {
                        f8.remove(f8.get(j));//Função remove
                    }
		}
            }
	}
    }
    
    /*
    *Função de Controle e Movimentação
    */
    
    public void Movimentation() {
   	for(int i = 0; i < q7.size(); i++) {// For para controlar a movimentação do carro
            q7.get(i).movimento(q7.get(i)); // chamando a funcao movimento e atribuindo ao carro
	}	
	for (int i = 0; i < truck.size(); i ++) { // For para controlar a movimentação do caminhão
            truck.get(i).movimento(truck.get(i)); // chamando a funcao movimento e atribuindo ao caminhao
	}
        for (int i = 0; i < f8.size(); i ++) {// For para controlar a movimentação da moto
            f8.get(i).movimento(f8.get(i)); // chamando a funcao movimento e atribuindo a moto
	}
        for (int i = 0; i < bmx.size(); i++){// For para controlar a movimentação da bmx
            bmx.get(i).movimento(bmx.get(i)); // chamando a funcao movimento e atribuindo a bike
        }
		
	GenerateVehicles();//Chama todas as funções para rodar o jogo
	collision();
	RedoMap();
	CreatingWorld();
    }
    
    /*
    *A função GenerateVehicles faz que com toda a vez que os Veiculos passem nas fábricas (2) seja gerado mais 1.
    */

    public void GenerateVehicles(){
		
        for(int carro = 0; carro < q7.size(); carro++) { 
            int x = q7.get(carro).getX(); // Armazena as Coordenadas do carro no eixo X na variavel x
            int y = q7.get(carro).getY(); // Armazena as Coordenadas do carro no eixo Y na variavel y
            	for(int i = 0; i < 30; i ++) { // Linhas
                    for(int j = 0; j < 60; j++) { //Colunas
			if(i == x && j == y){
                            if(MP[i][j] == 2 && q7.get(carro).getFabrica() == false) {
				q7.get(carro).setFabrica(true); // Já que o veículo passou numa fábrica, ele fica impossibilitado de gerar novamente caso não saia da fabrica
                                //Agora vamos adicionar um carro e seus atributos
				q7.add(new Carro((vei.setX()+1), (vei.setY()+1), 2, "verde", false));
                            }
			}
                    }
		}
            }
		
	for(int caminhao = 0; caminhao < truck.size(); caminhao++) {
            int x = truck.get(caminhao).getX();// Armazena as Coordenadas do caminhao no eixo X na variavel x
            int y = truck.get(caminhao).getY();// Armazena as Coordenadas do caminhao no eixo Y na variavel y
		for(int i = 0; i < 30; i ++) {// Linhas
                    for(int j = 0; j < 60; j++){// Colunas
			if(i == x && j == y) {
                            if(MP[i][j] == 2 && truck.get(caminhao).getFabrica() == false) {
                                    truck.get(caminhao).setFabrica(true);
                                    //Agora vamos adicionar um caminhao e seus atributos
                                    truck.add(new Caminhao((vei.setX()+1), (vei.setY()+1), 1, "vermelho", false));
                                    }
				}
                            }
                        }
                    }
		
	
	for(int moto = 0; moto < f8.size(); moto++) {
            int x = f8.get(moto).getX();// Armazena as Coordenadas da moto no eixo X na variavel x
            int y = f8.get(moto).getY();// Armazena as Coordenadas da moto no eixo Y na varivel y
		for(int i = 0; i < 30; i ++) {// Linhas
                    for(int j = 0; j < 60; j++){// Colunas
			if(i == x && j == y) {
                            if(MP[i][j] == 2 && f8.get(moto).getFabrica() == false) {
				f8.get(moto).setFabrica(true);
                                //Agora vamos adicionar uma nova moto e seus atributos
				f8.add(new Moto((vei.setX()+1), (vei.setY()+1), 3, "rosa", false));
                            }
			}
                    }
		}
            }
                
        for(int bike = 0; bike < bmx.size(); bike++) {
            int x = bmx.get(bike).getX();// Armazena as Coordenadas da bike no eixo X na variavel x
            int y = bmx.get(bike).getY();// Armazena as Coordenadas da bike no eixo Y na variavel y
		for(int i = 0; i < 30; i ++) {// Linhas
                    for(int j = 0; j < 60; j++){// Colunas
            		if(i == x && j == y) {
                            if(MP[i][j] == 2 && bmx.get(bike).getFabrica() == false) {
                                bmx.get(bike).setFabrica(true);
                                //Agora vamos adicionar uma nova Bike e seus atributos
				bmx.add(new Bike((vei.setX()+1), (vei.setY()+1), 4 , "azul claro", false));
                            }
			}
                    }
                }
            }
	}
    
    //A função VehicleGenerator é o inicio de Tudo, ela gera 10 veiculos em posições Aleatórias na MP.
    
    public void VehicleGenerator() {
	for(int i = 0; i < 10; i++) {
            q7.add(new Carro((vei.setX()+1), (vei.setY()+1), 2, "verde", false)); //Aqui usamos o atributo .ADD para adicionar um carro no eixo X e Y.
            while (MP[q7.get(i).getX()][q7.get(i).getY()] == 2) {// Esse while serve para inibir o aparecimento de um carro aonde tem uma fábrica (2).
		q7.get(i).setX();//Atributo para chamar um Carro no X
		q7.get(i).setY();//Atributo para chamar um Carro no Y
            }
            
            bmx.add(new Bike((vei.setX()+1), (vei.setY()+1), (int) (float) 1.5, "Azul Claro", false)); //Aqui usamos o atributo .ADD para adicionar uma Bike no eixo X e Y.
            while (MP[bmx.get(i).getX()][bmx.get(i).getY()] == 2) { // Esse while serve para inibir o aparecimento de uma Bike aonde tem uma fábrica (2).
		bmx.get(i).setX();//Atributo para chamar uma Bike no X
		bmx.get(i).setY();//Atributo para chamar uma BIke no Y
            }
            
            truck.add(new Caminhao((vei.setX()+1), (vei.setY()+1), 1, "vermelho", false)); //Aqui usamos o atributo .ADD para adicionar um Caminhão no eixo X e Y.
            while (MP[truck.get(i).getX()][truck.get(i).getY()] == 2) {// Esse while serve para inibir o aparecimento de um Caminhão aonde tem uma fábrica (2).
		truck.get(i).setX();//Atributo para chamar um Caminhao no X
		truck.get(i).setY();//Atributo para chamar um Caminhao no Y
            }

            f8.add(new Moto((vei.setX()+1), (vei.setY()+1), 2, "rosa", false));//Aqui usamos o atributo .ADD para adicionar uma Moto no eixo X e Y.
            while (MP[f8.get(i).getX()][f8.get(i).getY()] == 2) {// Esse while serve para inibir o aparecimento de uma Moto aonde tem uma fábrica (2).
		f8.get(i).setX(); //Atributo para chamar uma moto no X.
		f8.get(i).setY(); //Atributo para chamar uma moto no Y.
            }
	}		
    }
}