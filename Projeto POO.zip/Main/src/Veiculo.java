/**
 * 
 * Classe que gera um veículo 
 * @since 12-10-2018
 * @author Victor
 */
import java.util.Random;

public class Veiculo {
    
        /*
        *Função random, utilizada para gerar posições aleatórias
        */
	
	Random alea = new Random(); 
	
	public Veiculo() {
	x = 0; 
        y = 0; 
        velocidade = 0; 
        fabrica = false; 
        cor = null; 
	}
	
	public Veiculo(int x, int y, int velocidade, String cor, boolean fabrica) {
		this.x = x;
		this.y = y;
		this.velocidade = velocidade;
		this.cor = cor;
		this.fabrica = fabrica;
	}
	
	public int setX() {
		x = alea.nextInt(28);
		return x;
		
	}

	public void moveX(int x) {
		this.x = x;
	}

	public void moveY(int y) {
		this.y = y;
	}
	
	public int setY() {
		y = alea.nextInt(58);
		return y;
	}

	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getVelocidade() {
		return velocidade;
	}
	
	public String getCor() {
		return cor;
	}

	public void setFabrica(boolean condicao) {
		fabrica = condicao;
	}
	
	public boolean getFabrica() {
		return fabrica;
	}
	
	private int x; /// Coordenada X do veículo
	private int y; /// Coordenada Y do veículo
	private int velocidade; /// Variavel para velocidade
	private String cor; /// Cor do veículo
	private boolean fabrica; /// Variavel boolean para verificar se o veiculo está ou não em uma fabrica
	
}