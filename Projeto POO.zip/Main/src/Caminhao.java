/**
 * 
 * Classe que gera um veículo do tipo Caminhao
 * 
 * @author Victor 
 * @since 12-10-2018
 * @see Veiculo
 */
import java.util.Random;

public class Caminhao extends Veiculo{
    
	Veiculo vei = new Veiculo();
	
	public Caminhao (int x, int y, int vel, String cor, boolean fabrica) {
		super(x, y, vel, cor, fabrica);
	}

        private int movimentacao; //Variavel para mover o caminhao na matriz
        /*
        //Função Random para jogar o veiculo em lugares aleatórios.
        */
	Random alea = new Random();
        /*
        //Função que movimenta o veiculo
        */
	public void movimento(Caminhao truck) {
		movimentacao = alea.nextInt(4); //Next int gera posições aleatorias, abrindo de 0 a 3 jeitos de se movimentar 
		/*
		//Comandos para movimentação do carro baseado nas regras passa pelo professor 
                */
		if(movimentacao == 0) {//Condição de verificação de posições, se movimentação(posicão) for = 0 ela entra se nao passa pro proximo
			int x = truck.getX();
			x = x + 1;
			truck.moveX(AnalisarX(x));
		}
		
		if(movimentacao == 1) {
			int x = truck.getX();
			x = x - 1;
			truck.moveX(AnalisarX(x));
		}
		
		if(movimentacao == 2) {
			int y = truck.getY();
			y = y + 1;
			truck.moveY(AnalisarY(y));
		}
		
		if(movimentacao == 3) {
			int y = truck.getY();
			y = y - 1;
			truck.moveY(AnalisarY(y));
		}
	
	}
	

	//Função para ver se o caminhão chegou ao limite do mapa.
	
        public int AnalisarY(int y) {
		if (y >= 59) {
			y = 1;
		}
		if(y <= 0) {
			y = 58;
		}
		return y;
	}

	
        //Função para ver se o caminhão chegou ao limite do mapa em X.
	 
	 
	 
	public int AnalisarX(int x) {
		if (x >= 29) {
			x = 1;
		}
		if(x <= 0) {
			x = 28;
		}
		return x;
	}

}