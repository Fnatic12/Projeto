/**
 *@since 12-10-2018 
 *@author Victor 
 *@version 1.0
 */
public class Main {

	public static void main(String[] args) throws InterruptedException {
            
                /*
                *Instacioando a classe mundo para utilizar de seus atributos
                */
		Mundo m = new Mundo();
		/*
                *A função VehicleGenerator vai criar os veiculos
                */
		m.VehicleGenerator(); 
                /*
                *a Função CreatingWorld vai desenhar o mundo
                */
		m.CreatingWorld(); 
		
		int controle = 0;
		/*
                *Criacao de um while para o mapa se atualizar corretamente e os veiculos se moverem 
                */
		while (controle == 0) {
			m.Movimentation(); 
			Thread.sleep(600);  // Função
		}
	}
}