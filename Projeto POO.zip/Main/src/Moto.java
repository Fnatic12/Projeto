/**
 * 
 * Classe que gera um veículo do tipo moto
 * 
 * @author Victor 
 * @since 12-10-2018
 * @see Veiculo
 */
import java.util.Random;

public class Moto extends Veiculo{
    
        private int Movimentacao; /// Variável de movimentação 
    
	Veiculo vei = new Veiculo();

        public Moto (int x, int y, int velocidade, String cor, boolean fabrica) {
		super(x, y, velocidade, cor, fabrica);
	}
	
	//Função Random para gerar posições aleatorias para o veiculo
            
	Random alea = new Random();
	
        //Função que movimenta o carro
        
	public void movimento(Moto f8) {
		Movimentacao = alea.nextInt(5); //Next int gera posições aleatorias, abrindo de 0 a 3 jeitos de se movimentar
		
                
                
		if(Movimentacao == 0) {
			int x = f8.getX();
			x = x + 3;
			f8.moveX(AnalisarX(x));
		}
		
		if(Movimentacao == 1) {
			int x = f8.getX();
			x = x - 3;
			f8.moveX(AnalisarX(x));
		}
		
		if(Movimentacao == 2) {
			int y = f8.getY();
			y = y + 3;
			f8.moveY(AnalisarY(y));
		}
		
		if(Movimentacao == 3) {
			int y = f8.getY();
			y = y - 3;
			f8.moveY(AnalisarY(y));
		}
	
	}
	
	
	//Função para verificar se a moto chegou ao limite do mapa(mundo/matriz) em Y resetando a coordenada para a posição inicial apos execução

	public int AnalisarY(int y) {
		if (y >= 59) {
			y = 1;
		}
		if(y <= 0) {
			y = 58;
		}
		return y;
	}
	
	
	// Função para verificar se a moto chegou ao limite do mapa(mundo/matriz) em X resetando a coordenada para a posição inicial apos execução
	
	public int AnalisarX(int x) {
		if (x >= 29) {
			x = 1;
		}
		if(x <= 0) {
			x = 28;
		}
		return x;
	}

}