/**
 * 
 * Classe que gera um veículo do tipo Bike
 * 
 * @author Victor 
 * @since 12-10-2018
 * @see Veiculo
 */
import java.util.Random;

public class Bike extends Veiculo{
    
    Veiculo vei = new Veiculo();
    
    public Bike(int x, int y, int velo, String cor, boolean fab){
        super(x,y,velo,cor,fab);
    }
    
    private int movimentacao;
    
    //Função Random para gerar posições aleatorias para o veiculo
    
    Random alea = new Random();
    
    //Funcao que movimenta o veiculo
    
    public void movimento(Bike bmx){
        
        movimentacao = alea.nextInt(4); //Next int gera posições aleatorias, abrindo de 0 a 3 jeitos de se movimentar
        
        if(movimentacao == 0){
            int x = bmx.getX();
            x = x + 3/2;
            bmx.moveX(analisarX(x));
        }
        
        if(movimentacao == 1){
            int x = bmx.getX();
            x = x + 3/2;
            bmx.moveX(analisarX(x));
        }
    
        if(movimentacao == 2){
            int y = bmx.getY();
            y = y + 3/2;
            bmx.moveY(analisarY(y));
        }
    
        if(movimentacao == 3){
            int y = bmx.getY();
            y = y + 3/2;
            bmx.moveY(analisarY(y));
        }
 
    }
    
    //Função para verificar se o carro chegou ao limite da matriz(mapa) em Y
    
    public int analisarY(int y) {
		if (y >= 59) {
			y = 1;
		}
		if(y <= 0) {
			y = 58;
		}
		return y;
	}
	
	
    //Função para verificar se o carro chegou ao limite da matriz(mapa) em X 
	
    public int analisarX(int x) {
	if (x >= 29) {
                x = 1;
	}
	if(x <= 0) {
                x = 28;
	}
         return x;
    }
}