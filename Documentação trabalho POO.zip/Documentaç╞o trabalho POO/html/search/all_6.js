var searchData=
[
  ['setfabrica',['setFabrica',['../class_veiculo.html#a9896006415194ef92f5e11b67a0abc6a',1,'Veiculo']]],
  ['setx',['setX',['../class_veiculo.html#a28cf763354cb7f3d14272c9e793db57e',1,'Veiculo']]],
  ['sety',['setY',['../class_veiculo.html#ac0356427caf9839b90e558c99c09395f',1,'Veiculo']]]
];
