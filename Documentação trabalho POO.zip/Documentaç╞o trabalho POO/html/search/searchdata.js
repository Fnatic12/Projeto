var indexSectionsWithContent =
{
  0: "abcgmrsv",
  1: "bcmv",
  2: "bcmv",
  3: "abcgmrsv",
  4: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis"
};

